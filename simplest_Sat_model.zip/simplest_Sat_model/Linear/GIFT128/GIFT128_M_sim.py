from gurobipy import *
from functools import partial
from itertools import repeat
from multiprocessing import Pool,freeze_support
import os
import time
import random
import math

FullRound = 40

SearchRoundStart = 1
SearchRoundEnd = FullRound


ProbabilityBound = list([])
for i in range(FullRound+1):
    ProbabilityBound += [0]

def ExtractionResults(File):
    Result = "NoResult"
    Results = ""
    file = open(File,"rb")

    StopResult = 1
    StartResult = 0

    while StopResult:
        result = str(file.readline())
        if "[ result ]" in result:
            StartResult = 1
            continue#该行不读取
        if "run-time profiling" in result:
            StopResult = 0
            break
        
        if StartResult == 1:
            if "SATISFIABLE" in result:
                Result = "SATISFIABLE"
            if "UNSATISFIABLE" in result:
                Result = "UNSATISFIABLE"
                break 
            Results += result
        
    if Result == "SATISFIABLE":
        #剔除无效的字符串
        Results = Results.replace("b'","")
        Results = Results.replace(" '","")
        Results = Results.replace("'","")
        Results = Results.replace("c ","")
        Results = Results.replace("v","")
        Results = Results.replace("s ","")
        Results = Results.replace("SATISFIABLE","")
        Results = Results.replace("UNSATISFIABLE ","")
        Results = Results.replace("\\n","")
        #将字符串以空格为标准分成列表
        Results = Results.split(" ")
        del Results[0]
        del Results[len(Results)-1]

        for i in range(len(Results)):
            Results[i]= int(Results[i],10)
    return(Result,Results)

    
def GenerateAndCountVariables(Round,objLowerBound,objUpperBound):
    count_var_num = 0
    # Declare variables
    xin = []
    p = []
    q = []
    xout = []


    # Allocate variables
    for i in range(Round):
        xin.append([])
        p.append([])
        q.append([])
        for j in range(128):
            count_var_num += 1
            xin[i].append(count_var_num)
 
        for j in range(32):
            count_var_num += 1
            p[i].append(count_var_num) 
            count_var_num += 1
            q[i].append(count_var_num)

    for i in range(Round - 1):
        xout.append([])
        for j in range(128):
            xout[i].append(xin[i + 1][j])
    xout.append([])
    for i in range(128):
        count_var_num += 1
        xout[Round - 1].append(count_var_num)


    auxiliary_var_u = []
    for r in range(0,Round):
        auxiliary_var_u.append([])
        for i in range(64):
            if (r == (Round-1)) and (i ==63):
                continue
            auxiliary_var_u[r].append([])
            if(objLowerBound[(r)*(64)+i] == objUpperBound[(r)*(64)+i]):
                continue
            for j in range(objLowerBound[(r)*(64)+i],objUpperBound[(r)*(64)+i]):
                count_var_num += 1
                auxiliary_var_u[r][i].append(count_var_num)

    return(xin,xout,p,q,auxiliary_var_u,count_var_num)



def CountClausesInRoundFunction(Round, count_clause_num):
    # Nonzero input
    count_clause_num += 1
    # Clauses for Sbox
    for r in range(Round):
        for i in range(32):
            for j in range(31):
                count_clause_num += 1
    return count_clause_num

def GenRoundConstrain(TotalRound, xin,p,q,xout,file):

    # Add constraints to claim nonzero input
    clauseseq = ""
    for i in range(128):
        clauseseq += str(xin[0][i] + 1) + " "
    clauseseq += "0" + "\n"
    file.write(clauseseq)
    # Add constraints for the round function
    for r in range(TotalRound):
        y = list([])
        #P = [0, 33, 66, 99, 96, 1, 34, 67, 64, 97, 2, 35, 32, 65, 98, 3,
            #4, 37, 70, 103, 100, 5, 38, 71, 68, 101, 6, 39, 36, 69, 102, 7,
            #8, 41, 74, 107, 104, 9, 42, 75, 72, 105, 10, 43, 40, 73, 106, 11,
            #12, 45, 78, 111, 108, 13, 46, 79, 76, 109, 14, 47, 44, 77, 110, 15,
            #16, 49, 82, 115, 112, 17, 50, 83, 80, 113, 18, 51, 48, 81, 114, 19,
            #20, 53, 86, 119, 116, 21, 54, 87, 84, 117, 22, 55, 52, 85, 118, 23,
            #24, 57, 90, 123, 120, 25, 58, 91, 88, 121, 26, 59, 56, 89, 122, 27,
            #28, 61, 94, 127, 124, 29, 62, 95, 92, 125, 30, 63, 60, 93, 126, 31]
        P = [96, 1, 34, 67, 64, 97, 2, 35, 32, 65, 98, 3,  0, 33, 66,99,
            100, 5, 38, 71, 68, 101, 6, 39, 36, 69, 102, 7, 4, 37, 70, 103,
            104, 9, 42, 75, 72, 105, 10, 43, 40, 73, 106, 11, 8, 41, 74, 107,
            108, 13, 46, 79, 76, 109, 14, 47, 44, 77, 110, 15, 12, 45, 78, 111,
            112, 17, 50, 83, 80, 113, 18, 51, 48, 81, 114, 19, 16, 49, 82, 115,
            116, 21, 54, 87, 84, 117, 22, 55, 52, 85, 118, 23, 20, 53, 86, 119,
            120, 25, 58, 91, 88, 121, 26, 59, 56, 89, 122, 27, 24, 57, 90, 123,
            124, 29, 62, 95, 92, 125, 30, 63, 60, 93, 126, 31, 28, 61, 94, 127]

        SymbolicCNFConstraintForSbox = [
            [1, 0, 0, 0, 1, 1, 0, 1, -1, 0],
            [0, 0, 1, 0, 0, 1, 0, 0, 0, -1],
            [1, 1, 1, 1, 0, 0, 0, -1, 0, 0],
            [0, 1, 0, 0, 0, -1, 1, 1, 0, 1],
            [0, 1, 1, -1, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 1, 1, 0, 0, 0, 0, -1],
            [0, 1, 0, 0, 0, 1, 1, -1, 0, 1],
            [0, 0, 0, 0, 0, 0, -1, 0, 1, 0],
            [1, -1, 0, 0, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, -1, 0, -1, 0, 0, 0, 1],
            [0, 0, 0, -1, 1, -1, 0, 0, 0, 1],
            [0, -1, 1, 0, 0, 1, -1, -1, 0, 0],
            [1, 0, 0, 1, -1, 1, 0, 0, 0, 1],
            [1, 0, -1, 0, 0, -1, -1, 0, 0, 1],
            [-1, 1, 1, 1, 0, 1, 0, 0, 0, 0],
            [0, 1, 1, 0, 0, 0, -1, 1, 0, 1],
            [0, 0, 0, 0, 0, -1, 0, 0, 1, 0],
            [0, 0, -1, 1, -1, 0, 0, 0, 0, 1],
            [-1, 1, -1, 0, 0, 0, 0, -1, 0, 1],
            [0, 0, 1, 1, 0, 0, 0, 0, 0, -1],
            [0, -1, 1, 0, 0, 0, 1, 1, 0, 1],
            [0, 0, 0, 0, 1, 1, 0, 0, 0, -1],
            [0, 0, 0, 0, 0, 0, 0, -1, 1, 0],
            [-1, -1, 0, -1, -1, 1, 0, 0, 0, 1],
            [-1, -1, 0, 0, 0, -1, -1, 0, 0, 1],
            [0, 0, -1, 0, -1, 1, 0, 0, 0, 1],
            [-1, -1, -1, 0, 0, 0, -1, 0, 0, 1],
            [0, 0, 0, 0, -1, 0, 0, 0, 1, 0],
            [0, 0, -1, 0, 0, 1, 1, 1, 0, 1],
            [0, 0, -1, -1, -1, -1, 0, 0, 0, -1],
            [0, -1, 0, 0, 0, -1, 1, -1, 0, 1]]


        for i in range(128):
            y += [xout[r][P[i]]]
        for i in range(32):
            X = list([])
            for j in range(4):
                X += [xin[r][4 * i + j]]
            for j in range(4):
                X += [y[4 * i + j]]
            X += [p[r][i]]
            X += [q[r][i]]
            for j in range(31):
                clauseseq = ""
                for k in range(10):
                    if (SymbolicCNFConstraintForSbox[j][k] == -1):
                        clauseseq += "-" + str(X[k]) + " "
                    if (SymbolicCNFConstraintForSbox[j][k] == 1):
                        clauseseq += str(X[k]) + " "
                clauseseq += "0" + "\n"
                file.write(clauseseq)


def CountClausesInSequentialEncoding(TotalRound,Wvars, Uvars, objLowerBound,objUpperBound, count_clause_num):
    if(len(Uvars[0]) > 0):
        count_clause_num += 1
    if (objLowerBound[0] == 0) and (objUpperBound[0] == 0):
        count_clause_num += 1
    if (objLowerBound[0] == 1) and (objUpperBound[0] == 1):
        count_clause_num += 1

    if len(Wvars) > 2:
        for i in range(1,len(Wvars)-1):
            l_i_1 = objLowerBound[i-1]
            m_i_1 = objUpperBound[i-1]
            
            l_i = objLowerBound[i]
            m_i = objUpperBound[i]
            
            if(m_i == 0):
                count_clause_num += 1
                continue

            if(l_i == 0):
                count_clause_num += 1
                if(l_i_1 < m_i_1):#如果上一个位置也是需要被确定的值,因为如果上一个位置确定为1，则下一个肯定为1，所以没有必要，如果确定为0也没有必要
                    count_clause_num += 1


            if m_i > max(1,l_i):
                for j in range(max(1,l_i),m_i):
                    if(j <= l_i_1):#如果u[i][j]需要被确定且需要被确定,且u[i-1][j-1]位已经被确定为1了，则x_i =1可推导出u_i_j = 1
                        count_clause_num += 1
                    if(  (j > l_i_1) and (j <= m_i_1)):#如果u[i][j]需要被确定且需要被确定,且u[i-1][j-1]位是不确定的，则x_i =1且u[i-1][j-1]=1,可推导出u_i_j = 1. 注意其相对位置
                        count_clause_num += 1
                    if( (j >= l_i_1) and (j <= m_i_1 - 1) ):#如果u[i][j]需要被确定且需要被确定,且u[i-1][j]也是需要被确定的（如果其被确定为0或1，均不需要进行不等式约束）,则
                        count_clause_num += 1
                
            #其可能产生矛盾的部分,此时的约束应当是其不大于m_i
            if (l_i_1 == m_i):#如果本轮和前轮都达到了整体约束条件的边界,且前轮无0项
                count_clause_num += 1
            if ((m_i_1 == m_i) and (l_i_1 < m_i)):#如果本轮和前轮都达到了整体约束条件的边界,且前轮无0项,那么此时有辅助变量
                count_clause_num += 1
    
    #最后一比特的情况,如是前一个比特不是全0
    if len(Wvars) >= 2:
        i = len(Wvars) - 1
        l_i_1 = objLowerBound[i-1]
        m_i_1 = objUpperBound[i-1]#i-1比特的辅助变量，其重量小于等于m
        l_i = objLowerBound[i]
        m_i = objUpperBound[i]
            
        if ( (l_i_1 == m_i)):#如果本轮和前轮都达到了整体约束条件的边界,且前轮无0项
            count_clause_num += 1
        if ((m_i_1 == m_i) and (l_i_1 < m_i)):#如果本轮和前轮都达到了整体约束条件的边界,且前轮无0项,那么此时有辅助变量
            count_clause_num += 1
                
    return(count_clause_num)


def GenSequentialEncoding(TotalRound, Wvars, Uvars,objLowerBound,objUpperBound, file):
    if(len(Uvars[0]) > 0):
        clauseseq = "-" + str(Wvars[0]) + " " + str(Uvars[0][0]) + " 0" + "\n"
        file.write(clauseseq)
    if (objLowerBound[0] == 0) and (objUpperBound[0] == 0):
        clauseseq = "-" + str(Wvars[0]) +  " 0" + "\n"
        file.write(clauseseq)
    if (objLowerBound[0] == 1) and (objUpperBound[0] == 1):
        clauseseq =  str(Wvars[0]) +  " 0" + "\n"
        file.write(clauseseq)

    if len(Wvars) > 2:
        for i in range(1,len(Wvars)-1):
            l_i_1 = objLowerBound[i-1]
            m_i_1 = objUpperBound[i-1]
            
            l_i = objLowerBound[i]
            m_i = objUpperBound[i]
            
            if(m_i == 0):
                clauseseq = "-" + str(Wvars[i]) + " 0" + "\n"
                file.write(clauseseq)
                continue

            if(l_i == 0):
                clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][0]) + " 0" + "\n"#如果Wvars = 1，则u[i][0]为1
                file.write(clauseseq)
                if(l_i_1 < m_i_1):#如果上一个位置也是需要被确定的值,因为如果上一个位置确定为1，则下一个肯定为1，所以没有必要，如果确定为0也没有必要
                    clauseseq = "-" + str(Uvars[i-1][0]) + " " + str(Uvars[i][0]) + " 0" + "\n"#如果Wvars[i-1][0] = 1，则u[i][0]为1
                    file.write(clauseseq)


            if m_i > max(1,l_i):
                for j in range(max(1,l_i),m_i):
                    if(j <= l_i_1):#如果u[i][j]需要被确定且需要被确定,且u[i-1][j-1]位已经被确定为1了，则x_i =1可推导出u_i_j = 1
                        clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                    if(  (j > l_i_1) and (j <= m_i_1)):#如果u[i][j]需要被确定且需要被确定,且u[i-1][j-1]位是不确定的，则x_i =1且u[i-1][j-1]=1,可推导出u_i_j = 1. 注意其相对位置
                        clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][ j-1 - l_i_1]) + " " + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                    if( (j >= l_i_1) and (j <= m_i_1 - 1) ):#如果u[i][j]需要被确定且需要被确定,且u[i-1][j]也是需要被确定的（如果其被确定为0或1，均不需要进行不等式约束）,则
                        clauseseq =  "-" + str(Uvars[i-1][j - l_i_1]) + " "  + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                
         
            if (l_i_1 == m_i):
                clauseseq = "-" + str(Wvars[i]) +  " 0\n"
                file.write(clauseseq)
            if ((m_i_1 == m_i) and (l_i_1 < m_i)):
                clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][len(Uvars[i-1])-1]) + " 0\n" 
                file.write(clauseseq)
    

    if len(Wvars) >= 2:
        i = len(Wvars) - 1
        l_i_1 = objLowerBound[i-1]
        m_i_1 = objUpperBound[i-1]
        l_i = objLowerBound[i]
        m_i = objUpperBound[i]
            
        if ( (l_i_1 == m_i)):
            clauseseq = "-" + str(Wvars[i]) +  " 0" + "\n"
            file.write(clauseseq)
        if ((m_i_1 == m_i) and (l_i_1 < m_i)):
            clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][len(Uvars[i-1])-1]) + " 0" + "\n" 
            file.write(clauseseq)


            
def Decision(TotalRound,objLowerBound,objUpperBound):

    Probability = ProbabilityBound[TotalRound]
    count_var_num = 0
    count_clause_num = 0

    (xin,xout,p,q,auxiliary_var_u,count_var_num)= GenerateAndCountVariables(TotalRound,objLowerBound,objUpperBound)

    Wvars = []
    for r in range(TotalRound):
        for i in range(32):
            Wvars.append(p[r][i])
            Wvars.append(q[r][i])
    Uvars = []

    for uvar in auxiliary_var_u:
        Uvars += uvar


    count_clause_num = 0
    count_clause_num = CountClausesInRoundFunction(TotalRound,count_clause_num)


    count_clause_num = CountClausesInSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound,count_clause_num)


    file = open("Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf", "w")
    file.write("p cnf " + str(count_var_num) + " " + str(count_clause_num) + "\n")

    GenRoundConstrain(TotalRound,xin,p,q,xout,file)
    GenSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound, file)
    file.close()
    

    time_start = time.time()

    order = "d:/solver/cadical-master/build/cadical " + "Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf > Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt"
    os.system(order)
    time_end = time.time()


    (Result,Results)=ExtractionResults( "Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt")
  



    fileResult = open("ProcessResult.txt", "a")
    if (Result == "SATISFIABLE"):
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Sat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
    else:
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Unsat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
    fileResult.close()

    order = "rm Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf"
    os.system(order)

    return(Result,count_var_num,count_clause_num,time_end-time_start)


def AccurateLowerBound(obj,TOTALROUND,MatsuiProbabilityBound,BlockWeightSize):
    M = Model()
    M.Params.LogToConsole = 0

    wvariables = []
    for i in range(TOTALROUND):
        wvariables.append([])
        for j in range(BlockWeightSize):
            wvariables[i].append(M.addVar(vtype = GRB.BINARY))
    for e1 in range(TOTALROUND):
        for e2 in range(e1,max(TOTALROUND,e1+1)):
            constrain = LinExpr()
            for i in range(e1,e2+1):
                for j in range(BlockWeightSize):
                    constrain += wvariables[i][j]
            M.addConstr(constrain >= MatsuiProbabilityBound[e2-e1 +1])
    constrain = LinExpr()
    for i in range(TOTALROUND):
        for j in range(BlockWeightSize):
            constrain += wvariables[i][j]
    M.addConstr(constrain <= MatsuiProbabilityBound[TOTALROUND])

    wvar = []
    for var in wvariables:
        wvar+= var
    objconstrain = LinExpr()
    for i in range(obj+1):
        objconstrain += wvar[i]
    M.setObjective(objconstrain,GRB.MINIMIZE)
    M.optimize ()
    #M.write(str(obj) + "_" + str(TOTALROUND)+ "_M.lp")
    
    if (M.Status == 2) :
        return(round(M.objVal))
    else:
        return("infeasible")


def AccurateUpperBound(obj,TOTALROUND,MatsuiProbabilityBound,BlockWeightSize):
    M = Model()
    M.Params.LogToConsole = 0
    wvariables = []#所有的概率重点变量
    for i in range(TOTALROUND):
        wvariables.append([])
        for j in range(BlockWeightSize):
            wvariables[i].append(M.addVar(vtype = GRB.BINARY))
    for e1 in range(TOTALROUND):#约束条件的起点
        for e2 in range(e1,max(TOTALROUND,e1+1)):#约束条件的终点
            constrain = LinExpr()
            for i in range(e1,e2+1):
                for j in range(BlockWeightSize):
                    constrain += wvariables[i][j]
            M.addConstr(constrain >= MatsuiProbabilityBound[e2-e1 +1])#约束条件
    constrain = LinExpr()
    for i in range(TOTALROUND):
        for j in range(BlockWeightSize):
            constrain += wvariables[i][j]
    M.addConstr(constrain <= MatsuiProbabilityBound[TOTALROUND])

    wvar = []
    for var in wvariables:
        wvar+= var
    objconstrain = LinExpr()
    for i in range(obj+1):
        objconstrain += wvar[i]
    M.setObjective(objconstrain,GRB.MAXIMIZE)
    M.optimize ()
    #M.write(str(obj) + "_" + str(TOTALROUND)+ "_M.lp")
    
    if (M.Status == 2) :
        return(round(M.objVal))
    else:
        return("infeasible")




# main function
if __name__ == '__main__':
    Total_var_num = 0
    Total_clause_num =0
    Total_Solve_time = 0

    blockweightsize = 64

    for totalround in range(SearchRoundStart, SearchRoundEnd+1):
        count_var_num = 0
        count_clause_num = 0
        count_time = 0

     
        Result = "UNSATISFIABLE"
        ProbabilityBound[totalround] = ProbabilityBound[totalround-1] + ProbabilityBound[1]#设计最小的初始值

        while (Result == "UNSATISFIABLE"):#在判定之前将其最优值求出其精确的上下界值
            objLowerBoundList = []
            objUpperBoundList = []
            objLowerBound = []
            objUpperBound = []

            for i in range(totalround*64):#最后一比特不需要求界值，因为已经得到
                objLowerBoundList.append(i)
                objUpperBoundList.append(i)
            pool = Pool()#申请多核心
            objLowerBound = pool.map(partial(AccurateLowerBound,TOTALROUND = totalround,MatsuiProbabilityBound= ProbabilityBound,BlockWeightSize = blockweightsize),objLowerBoundList)
            objUpperBound = pool.map(partial(AccurateUpperBound,TOTALROUND = totalround,MatsuiProbabilityBound = ProbabilityBound,BlockWeightSize = blockweightsize),objUpperBoundList)
            pool.close()
            pool.join()
                
            #print(objLowerBound)
            #print(objUpperBound)
            #print(ProbabilityBound)

            if ("infeasible" in objLowerBound) or ("infeasible" in objUpperBound):
                ProbabilityBound[totalround] += 1
                continue
            (Result,var_num,clause_num,Time) = Decision(totalround,objLowerBound,objUpperBound)
            count_var_num += var_num
            count_clause_num += clause_num
            count_time += Time

            if (Result == "SATISFIABLE"):
                break
            ProbabilityBound[totalround] += 1

        Total_var_num += count_var_num
        Total_clause_num += count_clause_num
        Total_Solve_time += count_time
      

   
        file = open("RunTimeSummarise.out", "a")
        resultseq = "Round: " + str(totalround) + "; Probability: " + str(ProbabilityBound[totalround]) + "; Runtime: " + str(count_time) + " count_var_num: " + str(count_var_num) + " count_clause_num: " + str(count_clause_num) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num: " + str(Total_clause_num) +" Total_Solver_time: " + str(Total_Solve_time)  + "\n"
        file.write(resultseq)
        file.close()
        

    print(Total_Solve_time)
    print(str(ProbabilityBound))
    file = open("RunTimeSummarise.out", "a")
    resultseq = "Total Time of Solving SAT Model: " + str(Total_Solve_time) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num" + str(Total_clause_num)
    file.write(resultseq)
    file.close()

