from gurobipy import *
from functools import partial
from itertools import repeat
from multiprocessing import Pool,freeze_support
import os
import time
import random
import math



SIZE = [16,24,32,48,64]

ROTATIONA = [7,8,8,8,8]
ROTATIONB = [2,3,3,3,3]

FULLROUND = [22,23,27,29,34]

ChooseCipher = 0

SearchRoundStart = 1
SearchRoundEnd = FULLROUND[ChooseCipher]



ProbabilityBound = list([])
for i in range(SearchRoundEnd+1):
    ProbabilityBound += [0]


def ExtractionResults(File):
    Result = "NoResult"
    Results = ""
    file = open(File,"rb")

    StopResult = 1
    StartResult = 0

    while StopResult:
        result = str(file.readline())
        if "[ result ]" in result:
            StartResult = 1
            continue
        if "run-time profiling" in result:
            StopResult = 0
            break
        
        if StartResult == 1:
            if "SATISFIABLE" in result:
                Result = "SATISFIABLE"
            if "UNSATISFIABLE" in result:
                Result = "UNSATISFIABLE"
                break 
            Results += result
        
    if Result == "SATISFIABLE":

        Results = Results.replace("b'","")
        Results = Results.replace(" '","")
        Results = Results.replace("'","")
        Results = Results.replace("c ","")
        Results = Results.replace("v","")
        Results = Results.replace("s ","")
        Results = Results.replace("SATISFIABLE","")
        Results = Results.replace("UNSATISFIABLE ","")
        Results = Results.replace("\\n","")

        Results = Results.split(" ")
        del Results[0]
        del Results[len(Results)-1]

        for i in range(len(Results)):
            Results[i]= int(Results[i],10)
    return(Result,Results)

def GenerateAndCountVariables(Round,objLowerBound,objUpperBound):
    xin = []
    wvar = []
    xout = []
    count_var_num = 0
    for i in range(Round):
        xin.append([])
        wvar.append([])
        for j in range(2*SIZE[ChooseCipher]):
            count_var_num += 1
            xin[i].append(count_var_num)

        for j in range(SIZE[ChooseCipher]-1):
            count_var_num += 1
            wvar[i].append(count_var_num)

    for i in range(Round - 1):
        xout.append([])
        for j in range(2*SIZE[ChooseCipher]):
            xout[i].append(xin[i + 1][j])
    xout.append([])
    for j in range(2*SIZE[ChooseCipher]):
        count_var_num += 1
        xout[Round - 1].append(count_var_num)

    auxiliary_var_u = []
    for r in range(0,Round):
        auxiliary_var_u.append([])
        for i in range(SIZE[ChooseCipher]-1):
            if (r == (Round-1)) and (i ==SIZE[ChooseCipher]-2):
                continue
            auxiliary_var_u[r].append([])
            if(objLowerBound[(r)*(SIZE[ChooseCipher]-1)+i] == objUpperBound[(r)*(SIZE[ChooseCipher]-1)+i]):
                continue
            for j in range(objLowerBound[(r)*(SIZE[ChooseCipher]-1)+i],objUpperBound[(r)*(SIZE[ChooseCipher]-1)+i]):
                count_var_num += 1
                auxiliary_var_u[r][i].append(count_var_num)
    return(xin,wvar,xout,auxiliary_var_u,count_var_num)


def CountClausesInRoundFunction(Round, count_clause_num):
    count_clause_num += 1
    count_clause_num += Round*(4+13*(SIZE[ChooseCipher]-1) + 4*SIZE[ChooseCipher])
    return count_clause_num 

def GenRoundConstrain(TotalRound, xin,wvar,xout,file):

    clauseseq = ""
    for i in range(2*SIZE[ChooseCipher]):
        clauseseq += str(xin[0][i]) + " "
    clauseseq += "0\n"
    file.write(clauseseq)

    for r in range(TotalRound):
        Lxin = []
        Rxin = []
        Lxout = []
        Rxout = []
        LRotationAxin = []
        RRotationBxin = []
        for i in range(SIZE[ChooseCipher]):
            Lxin.append(xin[r][i])
            Rxin.append(xin[r][i+SIZE[ChooseCipher]])
            Lxout.append(xout[r][i])
            Rxout.append(xout[r][i+SIZE[ChooseCipher]])
        for i in range(SIZE[ChooseCipher]):
            LRotationAxin.append(Lxin[(i-ROTATIONA[ChooseCipher])%SIZE[ChooseCipher]])
            RRotationBxin.append(Rxin[(i+ROTATIONB[ChooseCipher])%SIZE[ChooseCipher]])


        i = SIZE[ChooseCipher]-1
        clauseseq = str(LRotationAxin[i]) + " " + str(Rxin[i]) + " "  + str(-(Lxout[i])) + " 0\n"
        file.write(clauseseq)
        clauseseq = str(LRotationAxin[i]) + " " + str(-(Rxin[i])) + " "  + str(Lxout[i]) + " 0\n"
        file.write(clauseseq)
        clauseseq = str(-(LRotationAxin[i])) + " " + str(Rxin[i]) + " "  + str(Lxout[i]) + " 0\n"
        file.write(clauseseq)
        clauseseq = str(-(LRotationAxin[i])) + " " + str(-(Rxin[i])) + " "  + str(-(Lxout[i])) + " 0\n"
        file.write(clauseseq)
 
        for i in range(0,SIZE[ChooseCipher]-1):
            clauseseq = str(LRotationAxin[i]) + " " + str(Rxin[i]) + " "  + str(-(Lxout[i])) + " " + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i]) + " " + str(-(Rxin[i])) + " "  + str(Lxout[i]) + " "  + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(Rxin[i]) + " "  + str(Lxout[i]) + " " + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(-(Rxin[i])) + " "  + str(-(Lxout[i])) + " " + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i]) + " " + str(Rxin[i]) + " "  + str(Lxout[i]) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i]) + " " + str(-(Rxin[i])) + " "  + str(-(Lxout[i])) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(Rxin[i]) + " "  + str(-(Lxout[i])) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(-(Rxin[i])) + " "  + str(Lxout[i]) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)

        for i in range(0,SIZE[ChooseCipher]-1):
            clauseseq = str(-(LRotationAxin[i+1]))                          + " " + str(Lxout[i+1]) + " " + str(wvar[r][i]) + " 0\n"
            file.write(clauseseq)
            clauseseq =                                      str(Rxin[i+1]) + " " + str(-(Lxout[i+1])) + " " + str(wvar[r][i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i+1]) + " " + str(-(Rxin[i+1]))                              + " " + str(wvar[r][i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " " + str(Lxout[i+1]) + " " + str(-(wvar[r][i])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " " + str(-(Lxout[i+1])) + " " + str(-(wvar[r][i])) + " 0\n"
            file.write(clauseseq)
        

        for i in range(0,SIZE[ChooseCipher]):
            clauseseq = str(Lxout[i]) + " " + str(RRotationBxin[i]) + " "  + str(-(Rxout[i])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(Lxout[i]) + " " + str(-(RRotationBxin[i])) + " "  + str(Rxout[i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(Lxout[i])) + " " + str(RRotationBxin[i]) + " "  + str(Rxout[i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(Lxout[i])) + " " + str(-(RRotationBxin[i])) + " "  + str(-(Rxout[i])) + " 0\n"
            file.write(clauseseq)


    
def CountClausesInSequentialEncoding(TotalRound,Wvars, Uvars, objLowerBound,objUpperBound, count_clause_num):
    if(len(Uvars[0]) > 0):
        count_clause_num += 1
    if (objLowerBound[0] == 0) and (objUpperBound[0] == 0):
        count_clause_num += 1
    if (objLowerBound[0] == 1) and (objUpperBound[0] == 1):
        count_clause_num += 1

    if len(Wvars) > 2:
        for i in range(1,len(Wvars)-1):
            l_i_1 = objLowerBound[i-1]
            m_i_1 = objUpperBound[i-1]
            
            l_i = objLowerBound[i]
            m_i = objUpperBound[i]
            
            if(m_i == 0):
                count_clause_num += 1
                continue

            if(l_i == 0):
                count_clause_num += 1
                if(l_i_1 < m_i_1):
                    count_clause_num += 1


            if m_i > max(1,l_i):
                for j in range(max(1,l_i),m_i):
                    if(j <= l_i_1):
                        count_clause_num += 1
                    if(  (j > l_i_1) and (j <= m_i_1)):
                        count_clause_num += 1
                    if( (j >= l_i_1) and (j <= m_i_1 - 1) ):
                        count_clause_num += 1
                
            
            if (l_i_1 == m_i):
                count_clause_num += 1
            if ((m_i_1 == m_i) and (l_i_1 < m_i)):
                count_clause_num += 1
    
    
    if len(Wvars) >= 2:
        i = len(Wvars) - 1
        l_i_1 = objLowerBound[i-1]
        m_i_1 = objUpperBound[i-1]
        l_i = objLowerBound[i]
        m_i = objUpperBound[i]
            
        if ( (l_i_1 == m_i)):
            count_clause_num += 1
        if ((m_i_1 == m_i) and (l_i_1 < m_i)):
            count_clause_num += 1
                
    return(count_clause_num)
    

    
def GenSequentialEncoding(TotalRound, Wvars, Uvars,objLowerBound,objUpperBound, file):
    if(len(Uvars[0]) > 0):
        clauseseq = "-" + str(Wvars[0]) + " " + str(Uvars[0][0]) + " 0" + "\n"
        file.write(clauseseq)
    if (objLowerBound[0] == 0) and (objUpperBound[0] == 0):
        clauseseq = "-" + str(Wvars[0]) +  " 0" + "\n"
        file.write(clauseseq)
    if (objLowerBound[0] == 1) and (objUpperBound[0] == 1):
        clauseseq =  str(Wvars[0]) +  " 0" + "\n"
        file.write(clauseseq)

    if len(Wvars) > 2:
        for i in range(1,len(Wvars)-1):
            l_i_1 = objLowerBound[i-1]
            m_i_1 = objUpperBound[i-1]
            
            l_i = objLowerBound[i]
            m_i = objUpperBound[i]
            
            if(m_i == 0):
                clauseseq = "-" + str(Wvars[i]) + " 0" + "\n"
                file.write(clauseseq)
                continue

            if(l_i == 0):
                clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][0]) + " 0" + "\n"
                file.write(clauseseq)
                if(l_i_1 < m_i_1):
                    clauseseq = "-" + str(Uvars[i-1][0]) + " " + str(Uvars[i][0]) + " 0" + "\n"
                    file.write(clauseseq)


            if m_i > max(1,l_i):
                for j in range(max(1,l_i),m_i):
                    if(j <= l_i_1):
                        clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                    if(  (j > l_i_1) and (j <= m_i_1)):
                        clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][ j-1 - l_i_1]) + " " + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                    if( (j >= l_i_1) and (j <= m_i_1 - 1) ):
                        clauseseq =  "-" + str(Uvars[i-1][j - l_i_1]) + " "  + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                
            
            if (l_i_1 == m_i):
                clauseseq = "-" + str(Wvars[i]) +  " 0\n"
                file.write(clauseseq)
            if ((m_i_1 == m_i) and (l_i_1 < m_i)):
                clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][len(Uvars[i-1])-1]) + " 0\n" 
                file.write(clauseseq)
    

    if len(Wvars) >= 2:
        i = len(Wvars) - 1
        l_i_1 = objLowerBound[i-1]
        m_i_1 = objUpperBound[i-1]
        l_i = objLowerBound[i]
        m_i = objUpperBound[i]
            
        if ( (l_i_1 == m_i)):
            clauseseq = "-" + str(Wvars[i]) +  " 0" + "\n"
            file.write(clauseseq)
        if ((m_i_1 == m_i) and (l_i_1 < m_i)):
            clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][len(Uvars[i-1])-1]) + " 0" + "\n" 
            file.write(clauseseq)
          
def Decision(TotalRound,objLowerBound,objUpperBound):

    Probability = ProbabilityBound[TotalRound]

    count_var_num = 0
    count_clause_num = 0

    (xin,wvar,xout,auxiliary_var_u,count_var_num) = GenerateAndCountVariables(TotalRound,objLowerBound,objUpperBound)

    Wvars = []
    for var in wvar:
        Wvars += var
    Uvars = []
    for uvar in auxiliary_var_u:
        Uvars += uvar


    count_clause_num = CountClausesInRoundFunction(TotalRound,count_clause_num)
    count_clause_num = CountClausesInSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound,count_clause_num)
    

    file = open("Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf", "w")
    file.write("p cnf " + str(count_var_num) + " " + str(count_clause_num) + "\n")


    GenRoundConstrain(TotalRound, xin,wvar,xout,file)
    GenSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound, file)
    file.close()

    time_start = time.time()

    order = "d:/solver/cadical-master/build/cadical " + "Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf > Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt"
    os.system(order)
    time_end = time.time()

    (Result,Results)=ExtractionResults( "Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt")

    if Result == "SATISFIABLE":
        wvarResult = []
        for var in wvar:
            for v in var :
                wvarResult.append(Results[v-1])
                



    fileResult = open("ProcessResult.txt", "a")
    if (Result == "SATISFIABLE"):
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Sat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
    else:
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Unsat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
    fileResult.close()

    order = "rm Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf"
    os.system(order)

    return(Result,count_var_num,count_clause_num,time_end-time_start)

def AccurateLowerBound(obj,TOTALROUND,MatsuiProbabilityBound,BlockWeightSize):
    M = Model()
    M.Params.LogToConsole = 0

    wvariables = []
    for i in range(TOTALROUND):
        wvariables.append([])
        for j in range(BlockWeightSize):
            wvariables[i].append(M.addVar(vtype = GRB.BINARY))
    for e1 in range(TOTALROUND):
        for e2 in range(e1,max(TOTALROUND,e1+1)):
            constrain = LinExpr()
            for i in range(e1,e2+1):
                for j in range(BlockWeightSize):
                    constrain += wvariables[i][j]
            M.addConstr(constrain >= MatsuiProbabilityBound[e2-e1 +1])
    constrain = LinExpr()
    for i in range(TOTALROUND):
        for j in range(BlockWeightSize):
            constrain += wvariables[i][j]
    M.addConstr(constrain <= MatsuiProbabilityBound[TOTALROUND])

    wvar = []
    for var in wvariables:
        wvar+= var
    objconstrain = LinExpr()
    for i in range(obj+1):
        objconstrain += wvar[i]
    M.setObjective(objconstrain,GRB.MINIMIZE)
    M.optimize ()

    
    if (M.Status == 2) :
        return(round(M.objVal))
    else:
        return("infeasible")


def AccurateUpperBound(obj,TOTALROUND,MatsuiProbabilityBound,BlockWeightSize):
    M = Model()
    M.Params.LogToConsole = 0
    wvariables = []
    for i in range(TOTALROUND):
        wvariables.append([])
        for j in range(BlockWeightSize):
            wvariables[i].append(M.addVar(vtype = GRB.BINARY))
    for e1 in range(TOTALROUND):
        for e2 in range(e1,max(TOTALROUND,e1+1)):
            constrain = LinExpr()
            for i in range(e1,e2+1):
                for j in range(BlockWeightSize):
                    constrain += wvariables[i][j]
            M.addConstr(constrain >= MatsuiProbabilityBound[e2-e1 +1])
    constrain = LinExpr()
    for i in range(TOTALROUND):
        for j in range(BlockWeightSize):
            constrain += wvariables[i][j]
    M.addConstr(constrain <= MatsuiProbabilityBound[TOTALROUND])

    wvar = []
    for var in wvariables:
        wvar+= var
    objconstrain = LinExpr()
    for i in range(obj+1):
        objconstrain += wvar[i]
    M.setObjective(objconstrain,GRB.MAXIMIZE)
    M.optimize ()

    
    if (M.Status == 2) :
        return(round(M.objVal))
    else:
        return("infeasible")





if __name__ == '__main__':
    Total_var_num = 0
    Total_clause_num =0
    Total_Solve_time = 0


    blockweightsize = SIZE[ChooseCipher]-1
    for totalround in range(SearchRoundStart, SearchRoundEnd+1):
        count_var_num = 0
        count_clause_num = 0
        count_time = 0

        Result = "UNSATISFIABLE"
        ProbabilityBound[totalround] = ProbabilityBound[totalround-1] + ProbabilityBound[1]

        while (Result == "UNSATISFIABLE"):
            objLowerBoundList = []
            objUpperBoundList = []
            objLowerBound = []
            objUpperBound = []

            for i in range(totalround*(SIZE[ChooseCipher]-1)):
                objLowerBoundList.append(i)
                objUpperBoundList.append(i)
            pool = Pool()
            objLowerBound = pool.map(partial(AccurateLowerBound,TOTALROUND = totalround,MatsuiProbabilityBound= ProbabilityBound,BlockWeightSize = blockweightsize),objLowerBoundList)
            objUpperBound = pool.map(partial(AccurateUpperBound,TOTALROUND = totalround,MatsuiProbabilityBound = ProbabilityBound,BlockWeightSize = blockweightsize),objUpperBoundList)
            pool.close()
            pool.join()
                
  

            if ("infeasible" in objLowerBound) or ("infeasible" in objUpperBound):
                ProbabilityBound[totalround] += 1
                continue
            
            (Result,var_num,clause_num,Time) = Decision(totalround,objLowerBound,objUpperBound)
            count_var_num += var_num
            count_clause_num += clause_num
            count_time += Time

            if (Result == "SATISFIABLE"):
                break
            ProbabilityBound[totalround] += 1

        Total_var_num += count_var_num
        Total_clause_num += count_clause_num
        Total_Solve_time += count_time
        


        file = open("RunTimeSummarise.out", "a")
        resultseq = "Round: " + str(totalround) + "; Probability: " + str(ProbabilityBound[totalround]) + "; Runtime: " + str(count_time) + " count_var_num: " + str(count_var_num) + " count_clause_num: " + str(count_clause_num) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num: " + str(Total_clause_num) +" Total_Solver_time: " + str(Total_Solve_time) + "\n"
        file.write(resultseq)
        file.close()


    print(str(ProbabilityBound))
    file = open("RunTimeSummarise.out", "a")
    resultseq = "Total Time of Solving SAT Model: " + str(Total_Solve_time) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num" + str(Total_clause_num)
    file.write(resultseq)
    file.close()

