import os
import time
import random



SIZE = [16,24,32,48,64]
ROTATIONA = [7,8,8,8,8]
ROTATIONB = [2,3,3,3,3]
FULLROUND = [22,23,27,29,34]

ChooseCipher = 0

SearchRoundStart = 1
SearchRoundEnd = FULLROUND[ChooseCipher]
InitialLowerBound = 0


ProbabilityBound = list([])
for i in range(SearchRoundEnd+1):
    ProbabilityBound += [0]


def ExtractionResults(File):
    Result = "NoResult"
    Results = ""


    file = open(File,"rb")
    StopResult = 1
    StartResult = 0

    while StopResult:
        result = str(file.readline())
        if "[ result ]" in result:
            StartResult = 1
            continue
        if "run-time profiling" in result:
            StopResult = 0
            break
        
        if StartResult == 1:
            if "SATISFIABLE" in result:
                Result = "SATISFIABLE"
            if "UNSATISFIABLE" in result:
                Result = "UNSATISFIABLE"
                break 
            Results += result
        
    if Result == "SATISFIABLE":
        Results = Results.replace("b'","")
        Results = Results.replace(" '","")
        Results = Results.replace("'","")
        Results = Results.replace("c ","")
        Results = Results.replace("v","")
        Results = Results.replace("s ","")
        Results = Results.replace("SATISFIABLE","")
        Results = Results.replace("UNSATISFIABLE ","")
        Results = Results.replace("\\n","")

        Results = Results.split(" ")
        del Results[0]
        del Results[len(Results)-1]

        for i in range(len(Results)):
            Results[i]= int(Results[i],10)
    return(Result,Results)

def GenerateAndCountVariables(Round,Probability):
    xin = []
    wvar = []
    xout = []

    count_var_num = 0
    for i in range(Round):
        xin.append([])
        wvar.append([])
        for j in range(2*SIZE[ChooseCipher]):
            count_var_num += 1
            xin[i].append(count_var_num)

        for j in range(SIZE[ChooseCipher]-1):
            count_var_num += 1
            wvar[i].append(count_var_num)

    for i in range(Round - 1):
        xout.append([])
        for j in range(2*SIZE[ChooseCipher]):
            xout[i].append(xin[i + 1][j])
    xout.append([])
    for j in range(2*SIZE[ChooseCipher]):
        count_var_num += 1
        xout[Round - 1].append(count_var_num)


    auxiliary_var_u = []
    for r in range(1,Round+1):
        auxiliary_var_u.append([])
        for i in range(SIZE[ChooseCipher]-1):
            if (r == Round) and (i ==SIZE[ChooseCipher]-2):
                continue
            auxiliary_var_u[r-1].append([])
            for j in range(0,Probability):
                count_var_num += 1
                auxiliary_var_u[r-1][i].append(count_var_num)
    return(xin,wvar,xout,auxiliary_var_u,count_var_num)



def CountClausesInRoundFunction(Round, count_clause_num):
    count_clause_num += 1
    count_clause_num += Round*(4+13*(SIZE[ChooseCipher]-1) + 4*(SIZE[ChooseCipher]))
    return count_clause_num


def GenRoundConstrain(TotalRound, xin,wvar,xout,file):
    clauseseq = ""
    for i in range(2*SIZE[ChooseCipher]):
        clauseseq += str(xin[0][i]) + " "
    clauseseq += "0\n"
    file.write(clauseseq)

    for r in range(TotalRound):
        Lxin = []
        Rxin = []
        Lxout = []
        Rxout = []
        LRotationAxin = []
        RRotationBxin = []
        for i in range(SIZE[ChooseCipher]):
            Lxin.append(xin[r][i])
            Rxin.append(xin[r][i+SIZE[ChooseCipher]])
            Lxout.append(xout[r][i])
            Rxout.append(xout[r][i+SIZE[ChooseCipher]])
        for i in range(SIZE[ChooseCipher]):
            LRotationAxin.append(Lxin[(i-ROTATIONA[ChooseCipher])%SIZE[ChooseCipher]])
            RRotationBxin.append(Rxin[(i+ROTATIONB[ChooseCipher])%SIZE[ChooseCipher]])


        i = SIZE[ChooseCipher]-1
        clauseseq = str(LRotationAxin[i]) + " " + str(Rxin[i]) + " "  + str(-(Lxout[i])) + " 0\n"
        file.write(clauseseq)
        clauseseq = str(LRotationAxin[i]) + " " + str(-(Rxin[i])) + " "  + str(Lxout[i]) + " 0\n"
        file.write(clauseseq)
        clauseseq = str(-(LRotationAxin[i])) + " " + str(Rxin[i]) + " "  + str(Lxout[i]) + " 0\n"
        file.write(clauseseq)
        clauseseq = str(-(LRotationAxin[i])) + " " + str(-(Rxin[i])) + " "  + str(-(Lxout[i])) + " 0\n"
        file.write(clauseseq)


        for i in range(0,SIZE[ChooseCipher]-1):
            clauseseq = str(LRotationAxin[i]) + " " + str(Rxin[i]) + " "  + str(-(Lxout[i])) + " " + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i]) + " " + str(-(Rxin[i])) + " "  + str(Lxout[i]) + " "  + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(Rxin[i]) + " "  + str(Lxout[i]) + " " + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(-(Rxin[i])) + " "  + str(-(Lxout[i])) + " " + str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " "  + str(Lxout[i+1]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i]) + " " + str(Rxin[i]) + " "  + str(Lxout[i]) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i]) + " " + str(-(Rxin[i])) + " "  + str(-(Lxout[i])) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(Rxin[i]) + " "  + str(-(Lxout[i])) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i])) + " " + str(-(Rxin[i])) + " "  + str(Lxout[i]) + " " + str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " "  + str(-(Lxout[i+1])) + " 0\n"
            file.write(clauseseq)


        for i in range(0,SIZE[ChooseCipher]-1):
            clauseseq = str(-(LRotationAxin[i+1]))                          + " " + str(Lxout[i+1]) + " " + str(wvar[r][i]) + " 0\n"
            file.write(clauseseq)
            clauseseq =                                      str(Rxin[i+1]) + " " + str(-(Lxout[i+1])) + " " + str(wvar[r][i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i+1]) + " " + str(-(Rxin[i+1]))                              + " " + str(wvar[r][i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(LRotationAxin[i+1]) + " " + str(Rxin[i+1]) + " " + str(Lxout[i+1]) + " " + str(-(wvar[r][i])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(LRotationAxin[i+1])) + " " + str(-(Rxin[i+1])) + " " + str(-(Lxout[i+1])) + " " + str(-(wvar[r][i])) + " 0\n"
            file.write(clauseseq)
        

        for i in range(0,SIZE[ChooseCipher]):
            clauseseq = str(Lxout[i]) + " " + str(RRotationBxin[i]) + " "  + str(-(Rxout[i])) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(Lxout[i]) + " " + str(-(RRotationBxin[i])) + " "  + str(Rxout[i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(Lxout[i])) + " " + str(RRotationBxin[i]) + " "  + str(Rxout[i]) + " 0\n"
            file.write(clauseseq)
            clauseseq = str(-(Lxout[i])) + " " + str(-(RRotationBxin[i])) + " "  + str(-(Rxout[i])) + " 0\n"
            file.write(clauseseq)


def CountClausesForMatsuiStrategy(Wvars,Uvars,Probability,left,right,m,count_clause_num):
    if (m > 0):
        if ((left == 0) and (right < len(Wvars)-1)):
            for i in range(1, right + 1):
                count_clause_num += 1
        if ((left > 0) and (right == len(Wvars)-1)):
            for i in range(0, Probability - m):
                count_clause_num += 1
            for i in range(0, Probability-m+1):
                count_clause_num += 1
        if ((left > 0) and (right < len(Wvars)-1)):
            for i in range(0, Probability-m):
                count_clause_num += 1
    if (m == 0):
        for i in range(left, right + 1):
            count_clause_num += 1
    return(count_clause_num)

def GenMatsuiConstraint(Wvars,Uvars,Probability,left,right,m,file):
    if (m > 0):
        if ((left == 0) and (right < len(Wvars)-1)):
            for i in range(1, right + 1):
                clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][m-1]) + " 0" + "\n"
                file.write(clauseseq)
        if ((left > 0) and (right == len(Wvars)-1)):
            for i in range(0, Probability - m):
                clauseseq = str(Uvars[left-1][i]) + " " + "-" + str(Uvars[right - 1][i+m]) + " 0" + "\n"
                file.write(clauseseq)
            for i in range(0, Probability-m+1):
                clauseseq = str(Uvars[left-1][i]) + " " + "-" + str(Uvars[right]) + " " + "-" + str(Uvars[right - 1][i+m-1]) + " 0" + "\n"
                file.write(clauseseq)
        if ((left > 0) and (right < len(Wvars)-1)):
            for i in range(0, Probability-m):
                clauseseq = str(Uvars[left-1][i]) + " " + "-" + str(Uvars[right][i+m]) + " 0" + "\n"
                file.write(clauseseq)
    if (m == 0):
        for i in range(left, right + 1):
            clauseseq = "-" + str(Wvars[i]) + " 0" + "\n"
            file.write(clauseseq)
    
def CountClausesInSequentialEncoding(TotalRound, Probability,Wvars, Uvars, count_clause_num):
    if (Probability > 0):
        count_clause_num += 1
        for i in range(1, Probability):
            count_clause_num += 1


        for i in range(1, len(Wvars)-1):
            count_clause_num += 1
            count_clause_num += 1
            count_clause_num += 1
        for j in range(1, Probability):
            for i in range(1, len(Wvars)-1):
                count_clause_num += 1
                count_clause_num += 1
        count_clause_num += 1

    elif (Probability == 0):
        for i in range(len(Wvars)):
            count_clause_num += 1

    return(count_clause_num)
    


def GenSequentialEncoding(TotalRound, Probability, Wvars, Uvars, file):

    if (Probability > 0):
        clauseseq = "-" + str(Wvars[0]) + " " + str(Uvars[0][0]) + " 0" + "\n"
        file.write(clauseseq)
        for i in range(1, Probability):
            clauseseq = "-" + str(Uvars[0][i]) + " 0" + "\n"
            file.write(clauseseq)


        for i in range(1, len(Wvars)-1):
            clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][0]) + " 0" + "\n"
            file.write(clauseseq)
            clauseseq = "-" + str(Uvars[i-1][0]) + " " + str(Uvars[i][0]) + " 0" + "\n"
            file.write(clauseseq)
            clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][Probability-1]) + " 0" + "\n"
            file.write(clauseseq)
        for j in range(1, Probability):
            for i in range(1, len(Wvars)-1):
                clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][j-1]) + " " + str(Uvars[i][j]) + " 0" + "\n"
                file.write(clauseseq)
                clauseseq = "-" + str(Uvars[i-1][j]) + " " + str(Uvars[i][j]) + " 0" + "\n"
                file.write(clauseseq)
        clauseseq = "-" + str(Wvars[len(Wvars)-1]) + " " + "-" + str(Uvars[len(Wvars)-2][Probability-1]) + " 0" + "\n"
        file.write(clauseseq)

    elif (Probability == 0):
        for i in range(len(Wvars)):
            clauseseq = "-" + str(Wvars[i]) + " 0\n"
            file.write(clauseseq)
 
def Decision(TotalRound, MatsuiRoundIndex):
    Probability = ProbabilityBound[TotalRound]
    time_start = time.time()
    count_var_num = 0
    count_clause_num = 0

 
    (xin,wvar,xout,auxiliary_var_u,count_var_num) = GenerateAndCountVariables(TotalRound,Probability)
    Wvars = []
    for var in wvar:
        Wvars += var
    Uvars = []
    for uvar in auxiliary_var_u:
        Uvars += uvar

    count_clause_num = CountClausesInRoundFunction(TotalRound,count_clause_num)
    count_clause_num = CountClausesInSequentialEncoding(TotalRound, Probability, Wvars, Uvars,count_clause_num)

    if len(MatsuiRoundIndex) > 0:
        for matsuiroundindex in MatsuiRoundIndex:
            StartingRound = matsuiroundindex[0]
            EndingRound = matsuiroundindex[1]
            LeftNode = StartingRound * (SIZE[ChooseCipher]-1)
            RightNode = EndingRound * (SIZE[ChooseCipher]-1) - 1
            
       
            m = Probability - ProbabilityBound[StartingRound] - ProbabilityBound[Round - EndingRound]
            count_clause_num = CountClausesForMatsuiStrategy( Wvars, Uvars,Probability,LeftNode,RightNode,m,count_clause_num)

    file = open("Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf", "w")
    file.write("p cnf " + str(count_var_num) + " " + str(count_clause_num) + "\n")

    GenRoundConstrain(TotalRound, xin,wvar,xout,file)
    GenSequentialEncoding(TotalRound, Probability,  Wvars, Uvars, file)

    if len(MatsuiRoundIndex) > 0:
        for matsuiroundindex in MatsuiRoundIndex:
            StartingRound = matsuiroundindex[0]
            EndingRound = matsuiroundindex[1]
            LeftNode = StartingRound * (SIZE[ChooseCipher]-1)
            RightNode = EndingRound * (SIZE[ChooseCipher]-1) - 1
            

            m = Probability - ProbabilityBound[StartingRound] - ProbabilityBound[Round - EndingRound]
            GenMatsuiConstraint( Wvars, Uvars,Probability,LeftNode,RightNode,m,file)

    file.close()
    time_start = time.time()

    order = "d:/solver/cadical-master/build/cadical " + "Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf > Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt"
    os.system(order)
    time_end = time.time()

    (Result,Results)=ExtractionResults( "Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt")
    time_end = time.time()
    if Result == "SATISFIABLE":
        wvarResult = []
        for var in wvar:
            for v in var :
                wvarResult.append(Results[v-1])

                


    if (Result == "SATISFIABLE"):
        print("Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Sat; TotalCost: " + str(time_end - time_start))
    else:
        print("Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Unsat; TotalCost: " + str(time_end - time_start))


    fileResult = open("ProcessResult.txt", "a")
    if (Result == "SATISFIABLE"):
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Sat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
    else:
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Unsat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))

    fileResult.close()

    order = "rm Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf"
    os.system(order)

    
    return(Result,count_var_num,count_clause_num,time_end - time_start)




if __name__ == '__main__':

    Total_var_num = 0
    Total_clause_num =0
    Total_Solve_time = 0


    for totalround in range(SearchRoundStart, SearchRoundEnd+1):
        count_var_num = 0
        count_clause_num = 0
        count_time = 0


        Result = "UNSATISFIABLE"
        ProbabilityBound[totalround] = ProbabilityBound[totalround-1] + ProbabilityBound[1]

        MatsuiCount = 0
        MatsuiRoundIndex=[]
        for Round in range(1, totalround + 1):
            MatsuiRoundIndex.append([])
            MatsuiRoundIndex[MatsuiCount].append(0)
            MatsuiRoundIndex[MatsuiCount].append(Round)
            MatsuiCount += 1

        file = open("MatsuiCondition.out", "a")
        resultseq = "Round: " + str(totalround) + "; Partial Constraint Num: " + str(MatsuiCount) + "\n"
        file.write(resultseq)
        file.write(str(MatsuiRoundIndex) + "\n")
        file.close()
        
        while (Result == "UNSATISFIABLE"):
            (Result,var_num,clause_num,Time) = Decision(totalround,MatsuiRoundIndex)

            count_var_num += var_num
            count_clause_num += clause_num
            count_time += Time

            if (Result == "SATISFIABLE"):
                break

            ProbabilityBound[totalround] += 1



        Total_var_num += count_var_num
        Total_clause_num += count_clause_num
        Total_Solve_time += count_time


        file = open("RunTimeSummarise.out", "a")
        resultseq = "Round: " + str(totalround) + "; Probability: " + str(ProbabilityBound[totalround]) + "; Runtime: " + str(count_time) + " count_var_num: " + str(count_var_num) + " count_clause_num: " + str(count_clause_num) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num: " + str(Total_clause_num) +" Total_Solver_time: " + str(Total_Solve_time)  + "\n"
        file.write(resultseq)
        file.close()


    print(str(ProbabilityBound))
    file = open("RunTimeSummarise.out", "a")
    resultseq = "Total Time of Solving SAT Model: " + str(Total_Solve_time) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num" + str(Total_clause_num)
    file.write(resultseq)
    file.close()





















