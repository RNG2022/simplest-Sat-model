from gurobipy import *
from functools import partial
from itertools import repeat
from multiprocessing import Pool,freeze_support
import os
import time
import random
import math

FullRound = 28

SearchRoundStart = 1
SearchRoundEnd = FullRound


ProbabilityBound100 = list([])
for i in range(FullRound+1):
    ProbabilityBound100 += [0]


ProbabilityBound141 = list([])
for i in range(FullRound+1):
    ProbabilityBound141 += [0]



def ExtractionResults(File):
    Result = "NoResult"
    Results = ""
    file = open(File,"rb")

    StopResult = 1
    StartResult = 0

    while StopResult:
        result = str(file.readline())
        if "[ result ]" in result:
            StartResult = 1
            continue
        if "run-time profiling" in result:
            StopResult = 0
            break
        
        if StartResult == 1:
            if "SATISFIABLE" in result:
                Result = "SATISFIABLE"
            if "UNSATISFIABLE" in result:
                Result = "UNSATISFIABLE"
                break 
            Results += result
        
    if Result == "SATISFIABLE":
        Results = Results.replace("b'","")
        Results = Results.replace(" '","")
        Results = Results.replace("'","")
        Results = Results.replace("c ","")
        Results = Results.replace("v","")
        Results = Results.replace("s ","")
        Results = Results.replace("SATISFIABLE","")
        Results = Results.replace("UNSATISFIABLE ","")
        Results = Results.replace("\\n","")
        Results = Results.split(" ")
        del Results[0]
        del Results[len(Results)-1]

        for i in range(len(Results)):
            Results[i]= int(Results[i],10)
    return(Result,Results)

    
def GenerateAndCountVariables(Round,objLowerBound,objUpperBound):
    count_var_num = 0
    xin = []
    p = []
    q = []
    xout = []


    for i in range(Round):
        xin.append([])
        p.append([])
        q.append([])
        for j in range(64):
            count_var_num += 1
            xin[i].append(count_var_num)
 
        for j in range(16):
            count_var_num += 1
            p[i].append(count_var_num) 
            count_var_num += 1
            q[i].append(count_var_num)

    for i in range(Round - 1):
        xout.append([])
        for j in range(64):
            xout[i].append(xin[i + 1][j])
    xout.append([])
    for i in range(64):
        count_var_num += 1
        xout[Round - 1].append(count_var_num)


    auxiliary_var_u = []
    for r in range(0,Round):
        auxiliary_var_u.append([])
        for i in range(3*16):
            if (r == (Round-1)) and (i ==3*16-1):
                continue
            auxiliary_var_u[r].append([])
            if(objLowerBound[(r)*(3*16)+i] == objUpperBound[(r)*(3*16)+i]):
                continue
            for j in range(objLowerBound[(r)*(3*16)+i],objUpperBound[(r)*(3*16)+i]):
                count_var_num += 1
                auxiliary_var_u[r][i].append(count_var_num)

    return(xin,xout,p,q,auxiliary_var_u,count_var_num)

def ImproveGenerateAndCountVariables(TotalRound,RestrictSUM100_1,count_var_num):
    SUM100Wvars = []

    for i in range(TotalRound):
        SUM100Wvars.append([])
        for j in range(16):
            count_var_num += 1
            SUM100Wvars[i].append(count_var_num)
    
    SUM100auxiliary_var_u = []
    for r in range(TotalRound):
        SUM100auxiliary_var_u.append([])
        for i in range(16):
            if (r == (TotalRound -1)) and (i== 15):
                 continue
            SUM100auxiliary_var_u[r].append([])
            for j in range(RestrictSUM100_1):
                count_var_num += 1
                SUM100auxiliary_var_u[r][i].append(count_var_num)
    return(SUM100Wvars,SUM100auxiliary_var_u,count_var_num)



def CountClausesInRoundFunction(Round, count_clause_num):
    count_clause_num += 1
    for r in range(Round):
        for i in range(16):
            for j in range(48):
                count_clause_num += 1
    return count_clause_num




def GenRoundConstrain(TotalRound, xin,p,q,xout,file):
    clauseseq = ""
    for i in range(64):
        clauseseq += str(xin[0][i]) + " "
    clauseseq += "0" + "\n"
    file.write(clauseseq)
    for r in range(TotalRound):
        y = list([])
        
        P = [48, 1, 18, 35, 32, 49, 2, 19, 16, 33, 50, 3, 0, 17, 34, 51,
            52, 5, 22, 39, 36, 53, 6, 23, 20, 37, 54, 7, 4, 21, 38, 55,
            56, 9, 26, 43, 40, 57, 10, 27, 24, 41, 58, 11, 8, 25, 42, 59,
            60, 13, 30, 47, 44, 61, 14, 31, 28, 45, 62, 15, 12, 29, 46, 63]

        SymbolicCNFConstraintForSbox = [
        [0, 0, 0, 1, 1, 0, 1, 0, 0, -1],
        [1, 1, 1, 0, -1, -1, 1, -1, 0, 0],
        [0, 0, 0, 0, 1, 1, 1, 1, -1, 0],
        [1, 1, 0, 0, 1, 0, -1, -1, 0, 0],
        [0, 0, 0, 0, 1, 0, 1, 1, 0, -1],
        [1, 0, 0, -1, 1, 0, 0, 0, 0, 1],
        [0, 1, 1, 0, -1, -1, -1, 1, 0, 0],
        [0, 1, -1, 1, 0, 0, 1, 1, 0, 0],
        [0, 1, -1, 1, 0, 0, -1, -1, 0, 0],
        [0, 0, 0, 0, -1, 0, 1, 0, 0, 1],
        [1, 1, -1, -1, 0, 1, 1, -1, 0, 0],
        [0, 1, -1, -1, 0, 1, -1, 1, 0, 0],
        [1, -1, 1, 1, 0, 0, 0, 1, 0, 0],
        [1, 0, 0, 0, 1, 1, 1, -1, 0, 0],
        [1, -1, 1, 0, -1, 1, -1, 0, 0, 0],
        [1, -1, 1, -1, 0, 1, 0, -1, 0, 0],
        [1, -1, 1, 0, 0, -1, -1, -1, -1, -1],
        [0, -1, 0, 0, 1, -1, -1, 1, 0, 0],
        [1, 0, 0, 1, 0, 0, -1, -1, 0, 1],
        [1, -1, -1, 0, 0, 1, -1, -1, -1, -1],
        [1, -1, -1, 1, 0, 0, 1, 0, 0, 0],
        [1, -1, -1, 0, -1, -1, 0, -1, 0, 0],
        [0, -1, 0, -1, 1, 0, -1, -1, 0, 0],
        [1, -1, -1, -1, 0, -1, -1, 0, 0, 0],
        [0, 0, 1, 0, 0, 1, 0, -1, 1, 0],
        [-1, 0, 0, 0, 0, 0, 0, 0, 1, 0],
        [0, 1, 1, 1, 0, 0, 1, 0, -1, 0],
        [0, 0, 0, 1, 1, 0, 0, 1, 0, -1],
        [0, 1, 1, 1, 0, -1, 0, 1, 0, 0],
        [0, 0, 0, 0, -1, 0, 0, 0, 1, 0],
        [0, 1, 1, 1, 0, 0, 0, 0, 0, -1],
        [0, 1, 0, 0, 1, 1, 0, 1, -1, 0],
        [0, 0, 0, 0, 0, 0, 1, -1, 1, 0],
        [0, 1, 0, -1, 0, 0, 0, 0, 0, 1],
        [0, 0, -1, 0, 0, -1, 0, 0, 1, 0],
        [0, 0, 0, 0, -1, 0, 0, 1, 0, 1],
        [-1, 0, 0, -1, 0, 0, -1, 0, 0, 1],
        [-1, 1, 0, -1, -1, 0, -1, -1, 0, 0],
        [-1, -1, 1, 1, 0, 0, 0, -1, 0, 0],
        [-1, 0, 0, -1, 0, 0, 0, -1, 0, 1],
        [-1, 0, 1, 0, -1, 1, 1, -1, 0, 0],
        [-1, -1, 1, -1, -1, -1, 0, 1, 0, 0],
        [-1, 0, 0, 0, 1, -1, 1, -1, 0, 0],
        [-1, -1, -1, 1, 0, 0, -1, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, -1, 1, 1, 0],
        [-1, -1, -1, -1, -1, 1, 0, 1, 0, 0],
        [-1, -1, 0, -1, -1, 0, 1, 1, 0, 0],
        [-1, 0, -1, -1, 0, -1, 1, -1, 0, 0]]

        for i in range(64):
            y += [xout[r][P[i]]]
        for i in range(16):
            X = list([])
            for j in range(4):
                X += [xin[r][4 * i + j]]
            for j in range(4):
                X += [y[4 * i + j]]
            X += [p[r][i]]
            X += [q[r][i]]
            for j in range(48):
                clauseseq = ""
                for k in range(10):
                    if (SymbolicCNFConstraintForSbox[j][k] == -1):
                        clauseseq += "-" + str(X[k]) + " "
                    if (SymbolicCNFConstraintForSbox[j][k] == 1):
                        clauseseq += str(X[k]) + " "
                clauseseq += "0" + "\n"
                file.write(clauseseq)

def CountClausesInSequentialEncoding(TotalRound,Wvars, Uvars, objLowerBound,objUpperBound, count_clause_num):
    if(len(Uvars[0]) > 0):
        count_clause_num += 1
    if (objLowerBound[0] == 0) and (objUpperBound[0] == 0):
        count_clause_num += 1
    if (objLowerBound[0] == 1) and (objUpperBound[0] == 1):
        count_clause_num += 1

    if len(Wvars) > 2:
        for i in range(1,len(Wvars)-1):
            l_i_1 = objLowerBound[i-1]
            m_i_1 = objUpperBound[i-1]
            
            l_i = objLowerBound[i]
            m_i = objUpperBound[i]
            
            if(m_i == 0):
                count_clause_num += 1
                continue

            if(l_i == 0):
                count_clause_num += 1
                if(l_i_1 < m_i_1):
                    count_clause_num += 1


            if m_i > max(1,l_i):
                for j in range(max(1,l_i),m_i):
                    if(j <= l_i_1):
                        count_clause_num += 1
                    if(  (j > l_i_1) and (j <= m_i_1)):
                        count_clause_num += 1
                    if( (j >= l_i_1) and (j <= m_i_1 - 1) ):
                        count_clause_num += 1
                
      
            if (l_i_1 == m_i):
                count_clause_num += 1
            if ((m_i_1 == m_i) and (l_i_1 < m_i)):
                count_clause_num += 1
    

    if len(Wvars) >= 2:
        i = len(Wvars) - 1
        l_i_1 = objLowerBound[i-1]
        m_i_1 = objUpperBound[i-1]
        l_i = objLowerBound[i]
        m_i = objUpperBound[i]
            
        if ( (l_i_1 == m_i)):
            count_clause_num += 1
        if ((m_i_1 == m_i) and (l_i_1 < m_i)):
            count_clause_num += 1
                
    return(count_clause_num)


def GenSequentialEncoding(TotalRound, Wvars, Uvars,objLowerBound,objUpperBound, file):
    if(len(Uvars[0]) > 0):
        clauseseq = "-" + str(Wvars[0]) + " " + str(Uvars[0][0]) + " 0" + "\n"
        file.write(clauseseq)
    if (objLowerBound[0] == 0) and (objUpperBound[0] == 0):
        clauseseq = "-" + str(Wvars[0]) +  " 0" + "\n"
        file.write(clauseseq)
    if (objLowerBound[0] == 1) and (objUpperBound[0] == 1):
        clauseseq =  str(Wvars[0]) +  " 0" + "\n"
        file.write(clauseseq)

    if len(Wvars) > 2:
        for i in range(1,len(Wvars)-1):
            l_i_1 = objLowerBound[i-1]
            m_i_1 = objUpperBound[i-1]
            
            l_i = objLowerBound[i]
            m_i = objUpperBound[i]
            
            if(m_i == 0):
                clauseseq = "-" + str(Wvars[i]) + " 0" + "\n"
                file.write(clauseseq)
                continue

            if(l_i == 0):
                clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][0]) + " 0" + "\n"
                file.write(clauseseq)
                if(l_i_1 < m_i_1):
                    clauseseq = "-" + str(Uvars[i-1][0]) + " " + str(Uvars[i][0]) + " 0" + "\n"
                    file.write(clauseseq)


            if m_i > max(1,l_i):
                for j in range(max(1,l_i),m_i):
                    if(j <= l_i_1):
                        clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                    if(  (j > l_i_1) and (j <= m_i_1)):
                        clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][ j-1 - l_i_1]) + " " + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                    if( (j >= l_i_1) and (j <= m_i_1 - 1) ):
                        clauseseq =  "-" + str(Uvars[i-1][j - l_i_1]) + " "  + str(Uvars[i][j - l_i]) + " 0\n"
                        file.write(clauseseq)
                
            
            if (l_i_1 == m_i):
                clauseseq = "-" + str(Wvars[i]) +  " 0\n"
                file.write(clauseseq)
            if ((m_i_1 == m_i) and (l_i_1 < m_i)):
                clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][len(Uvars[i-1])-1]) + " 0\n" 
                file.write(clauseseq)
    

    if len(Wvars) >= 2:
        i = len(Wvars) - 1
        l_i_1 = objLowerBound[i-1]
        m_i_1 = objUpperBound[i-1]
        l_i = objLowerBound[i]
        m_i = objUpperBound[i]
            
        if ( (l_i_1 == m_i)):
            clauseseq = "-" + str(Wvars[i]) +  " 0" + "\n"
            file.write(clauseseq)
        if ((m_i_1 == m_i) and (l_i_1 < m_i)):
            clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][len(Uvars[i-1])-1]) + " 0" + "\n" 
            file.write(clauseseq)


def ImproveCountClausesInSequentialEncoding(TotalRound, Probability,Wvars, Uvars, count_clause_num):
    if (Probability > 0):
        count_clause_num += 1
        for i in range(1, Probability):
            count_clause_num += 1

        for i in range(1, len(Wvars)-1):
            count_clause_num += 1
            count_clause_num += 1
            count_clause_num += 1
        for j in range(1, Probability):
            for i in range(1, len(Wvars)-1):
                count_clause_num += 1
                count_clause_num += 1
        count_clause_num += 1

    elif (Probability == 0):
        for i in range(len(Wvars)):
            count_clause_num += 1

    return(count_clause_num)
    
    
def ImproveGenSequentialEncoding(TotalRound, Probability, Wvars, Uvars, file):

    if (Probability > 0):
        clauseseq = "-" + str(Wvars[0]) + " " + str(Uvars[0][0]) + " 0" + "\n"
        file.write(clauseseq)
        for i in range(1, Probability):
            clauseseq = "-" + str(Uvars[0][i]) + " 0" + "\n"
            file.write(clauseseq)


        for i in range(1, len(Wvars)-1):
            clauseseq = "-" + str(Wvars[i]) + " " + str(Uvars[i][0]) + " 0" + "\n"
            file.write(clauseseq)
            clauseseq = "-" + str(Uvars[i-1][0]) + " " + str(Uvars[i][0]) + " 0" + "\n"
            file.write(clauseseq)
            clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][Probability-1]) + " 0" + "\n"
            file.write(clauseseq)
        for j in range(1, Probability):
            for i in range(1, len(Wvars)-1):
                clauseseq = "-" + str(Wvars[i]) + " " + "-" + str(Uvars[i-1][j-1]) + " " + str(Uvars[i][j]) + " 0" + "\n"
                file.write(clauseseq)
                clauseseq = "-" + str(Uvars[i-1][j]) + " " + str(Uvars[i][j]) + " 0" + "\n"
                file.write(clauseseq)
        clauseseq = "-" + str(Wvars[len(Wvars)-1]) + " " + "-" + str(Uvars[len(Wvars)-2][Probability-1]) + " 0" + "\n"
        file.write(clauseseq)

    elif (Probability == 0):
        for i in range(len(Wvars)):
            clauseseq = "-" + str(Wvars[i]) + " 0\n"
            file.write(clauseseq)

def AccurateLowerBound(obj,TOTALROUND,MatsuiProbabilityBound,BlockWeightSize):
    M = Model()
    M.Params.LogToConsole = 0

    wvariables = []
    for i in range(TOTALROUND):
        wvariables.append([])
        for j in range(BlockWeightSize):
            wvariables[i].append(M.addVar(vtype = GRB.BINARY))
    for e1 in range(TOTALROUND):
        for e2 in range(e1,max(TOTALROUND,e1+1)):
            constrain = LinExpr()
            for i in range(e1,e2+1):
                for j in range(BlockWeightSize):
                    constrain += wvariables[i][j]
            M.addConstr(constrain >= MatsuiProbabilityBound[e2-e1 +1])
    constrain = LinExpr()
    for i in range(TOTALROUND):
        for j in range(BlockWeightSize):
            constrain += wvariables[i][j]
    M.addConstr(constrain <= MatsuiProbabilityBound[TOTALROUND])

    wvar = []
    for var in wvariables:
        wvar+= var
    objconstrain = LinExpr()
    for i in range(obj+1):
        objconstrain += wvar[i]
    M.setObjective(objconstrain,GRB.MINIMIZE)
    M.optimize ()

    
    if (M.Status == 2) :
        return(round(M.objVal))
    else:
        return("infeasible")


def AccurateUpperBound(obj,TOTALROUND,MatsuiProbabilityBound,BlockWeightSize):
    M = Model()
    M.Params.LogToConsole = 0
    wvariables = []
    for i in range(TOTALROUND):
        wvariables.append([])
        for j in range(BlockWeightSize):
            wvariables[i].append(M.addVar(vtype = GRB.BINARY))
    for e1 in range(TOTALROUND):
        for e2 in range(e1,max(TOTALROUND,e1+1)):
            constrain = LinExpr()
            for i in range(e1,e2+1):
                for j in range(BlockWeightSize):
                    constrain += wvariables[i][j]
            M.addConstr(constrain >= MatsuiProbabilityBound[e2-e1 +1])
    constrain = LinExpr()
    for i in range(TOTALROUND):
        for j in range(BlockWeightSize):
            constrain += wvariables[i][j]
    M.addConstr(constrain <= MatsuiProbabilityBound[TOTALROUND])

    wvar = []
    for var in wvariables:
        wvar+= var
    objconstrain = LinExpr()
    for i in range(obj+1):
        objconstrain += wvar[i]
    M.setObjective(objconstrain,GRB.MAXIMIZE)
    M.optimize ()

    
    if (M.Status == 2) :
        return(round(M.objVal))
    else:
        return("infeasible")
            
def Decision(TotalRound,objLowerBound,objUpperBound):

    Probability = ProbabilityBound100[TotalRound]
    count_var_num = 0
    count_clause_num = 0

    (xin,xout,p,q,auxiliary_var_u,count_var_num)= GenerateAndCountVariables(TotalRound,objLowerBound,objUpperBound)

    Wvars = []
    for r in range(TotalRound):
        for i in range(16):
            Wvars.append(p[r][i])
            Wvars.append(p[r][i])
            Wvars.append(q[r][i])
    Uvars = []

    for uvar in auxiliary_var_u:
        Uvars += uvar


    count_clause_num = 0
    count_clause_num = CountClausesInRoundFunction(TotalRound,count_clause_num)


    count_clause_num = CountClausesInSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound,count_clause_num)


    file = open("Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf", "w")
    file.write("p cnf " + str(count_var_num) + " " + str(count_clause_num) + "\n")

    GenRoundConstrain(TotalRound,xin,p,q,xout,file)
    GenSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound, file)
    file.close()
    

    time_start = time.time()

    order = "d:/solver/cadical-master/build/cadical " + "Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf > Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt"
    os.system(order)
    time_end = time.time()


    (Result,Results)=ExtractionResults( "Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt")



    fileResult = open("ProcessResult.txt", "a")
    if (Result == "SATISFIABLE"):
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Sat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
    else:
        fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Unsat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
    fileResult.close()

    order = "rm Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf"
    os.system(order)

    return(Result,Results,p,q,count_var_num,count_clause_num,time_end-time_start)

def ImproveDecision(TotalRound,objLowerBound,objUpperBound,RestrictSUM100_1):
    
        Probability = ProbabilityBound100[TotalRound]
        count_var_num = 0
        count_clause_num = 0

        (xin,xout,p,q,auxiliary_var_u,count_var_num)= GenerateAndCountVariables(TotalRound,objLowerBound,objUpperBound)

        (SUM100Wvars,SUM100auxiliary_var_u,count_var_num) = ImproveGenerateAndCountVariables(TotalRound,RestrictSUM100_1,count_var_num)

        Wvars = []
        for r in range(TotalRound):
            for i in range(16):
                Wvars.append(p[r][i])
                Wvars.append(p[r][i])
                Wvars.append(q[r][i])
        Uvars = []

        for uvar in auxiliary_var_u:
            Uvars += uvar

        ImproveWvars = []
        for r in range(TotalRound):
            for i in range(16):
                ImproveWvars.append(SUM100Wvars[r][i])
        ImproveUvars = []

        for uvar in SUM100auxiliary_var_u:
            ImproveUvars += uvar



        count_clause_num = 0
        count_clause_num = CountClausesInRoundFunction(TotalRound,count_clause_num)
        for r in range(TotalRound):
            for i in range(16):
                count_clause_num = count_clause_num +3


        count_clause_num = CountClausesInSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound,count_clause_num)

        count_clause_num = ImproveCountClausesInSequentialEncoding(TotalRound, RestrictSUM100_1, ImproveWvars, ImproveUvars,count_clause_num)

        file = open("Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf", "w")
        file.write("p cnf " + str(count_var_num) + " " + str(count_clause_num) + "\n")

        GenRoundConstrain(TotalRound,xin,p,q,xout,file)
        GenSequentialEncoding(TotalRound, Wvars, Uvars, objLowerBound,objUpperBound, file)
        ImproveGenSequentialEncoding(TotalRound, RestrictSUM100_1,  ImproveWvars, ImproveUvars, file)

        for r in range(TotalRound):
            for i in range(16):
                clauseseq = "-" + str(p[r][i]) + " " + "-" + str(SUM100Wvars[r][i]) +  " 0" + "\n"
                file.write(clauseseq)
                clauseseq =  str(p[r][i]) + " " + str(q[r][i]) + " " + "-" + str(SUM100Wvars[r][i]) +  " 0" + "\n"
                file.write(clauseseq)
                clauseseq =  str(p[r][i]) + " "  + "-" + str(q[r][i]) + " "  + str(SUM100Wvars[r][i]) +  " 0" + "\n"
                file.write(clauseseq)
        file.close()
        

        time_start = time.time()

        order = "d:/solver/cadical-master/build/cadical " + "Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf > Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt"
        os.system(order)
        time_end = time.time()


        (Result,Results)=ExtractionResults( "Round" + str(TotalRound) + "-Probability" + str(Probability) + "-solution.txt")
    


        fileResult = open("ProcessResult.txt", "a")
        if (Result == "SATISFIABLE"):
            fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Sat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
        else:
            fileResult.write("\n Round:" + str(TotalRound) + "; Probability: " + str(Probability) + "; Unsat; TotalCost: " + str(time_end - time_start)+ " p: " +str(count_var_num) +" cnf: " + str(count_clause_num))
        fileResult.close()

        order = "rm Problem-Round" + str(TotalRound) + "-Probability" + str(Probability) + ".cnf"
        os.system(order)

        return(Result,Results,p,q,count_var_num,count_clause_num,time_end-time_start)
    

if __name__ == '__main__':
    Total_var_num = 0
    Total_clause_num =0
    Total_Solve_time = 0


    for totalround in range(SearchRoundStart, SearchRoundEnd+1):


        file = open("ProbabilityBoundResults.out","a")
        file.write("\nRound :" + str(totalround-1))
        file.write("\nThe ProbabilityBound100:" + str(ProbabilityBound100))
        file.write("\nThe ProbabilityBound141:" + str(ProbabilityBound141))
  
        file.close()


        count_var_num = 0
        count_clause_num = 0
        count_time = 0




        Result = "UNSATISFIABLE"
        ProbabilityBound100[totalround] = ProbabilityBound100[totalround-1] + ProbabilityBound100[1]
        blockweightsize = 3*16


        while (Result == "UNSATISFIABLE"):
            objLowerBoundList = []
            objUpperBoundList = []
            objLowerBound = []
            objUpperBound = []

            for i in range(totalround*blockweightsize):
                objLowerBoundList.append(i)
                objUpperBoundList.append(i)
            pool = Pool()
            objLowerBound = pool.map(partial(AccurateLowerBound,TOTALROUND = totalround,MatsuiProbabilityBound= ProbabilityBound100,BlockWeightSize = blockweightsize),objLowerBoundList)
            objUpperBound = pool.map(partial(AccurateUpperBound,TOTALROUND = totalround,MatsuiProbabilityBound = ProbabilityBound100,BlockWeightSize = blockweightsize),objUpperBoundList)
            pool.close()
            pool.join()
                


            if ("infeasible" in objLowerBound) or ("infeasible" in objUpperBound):
                ProbabilityBound100[totalround] += 1
                continue
            (Result,Results,p,q,var_num,clause_num,Time) = Decision(totalround,objLowerBound,objUpperBound)
            count_var_num += var_num
            count_clause_num += clause_num
            count_time += Time

            if (Result == "SATISFIABLE"):
                break
            ProbabilityBound100[totalround] += 1
        
        SUM100_1 = 0
        SUM100_2 = 0
        SUM100_3 = 0

        
        for i in range(totalround):
            for j in range(16):
                if  (Results[p[i][j]-1] < 0) and (Results[q[i][j]-1] > 0) :
                    SUM100_1 += 1
                if   (Results[p[i][j]-1] > 0) and (Results[q[i][j]-1] < 0):
                    SUM100_2 += 1
                if   (Results[p[i][j]-1] > 0) and (Results[q[i][j]-1] > 0):
                    SUM100_3 += 1
        TheTrueProbability100 = 1.415*SUM100_1 + 2*SUM100_2 + 3*SUM100_3
        print(TheTrueProbability100)
        print(SUM100_1)

        if SUM100_1 == 0:

            ProbabilityBound141[totalround] = TheTrueProbability100

            Total_var_num += count_var_num
            Total_clause_num += count_clause_num
            Total_Solve_time += count_time


            file = open("RunTimeSummarise.out", "a")
            resultseq = "Round: " + str(totalround) + "; Probability: " + str(TheTrueProbability100) + "; Runtime: " + str(count_time) + " count_var_num: " + str(count_var_num) + " count_clause_num: " + str(count_clause_num) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num: " + str(Total_clause_num) +" Total_Solver_time: " + str(Total_Solve_time) + "\n"
            file.write(resultseq)
            file.close()
            continue

        Result =   "SATISFIABLE"
        while SUM100_1 > 0 and Result == "SATISFIABLE":
            RestrictSUM100_1 = SUM100_1 - 1 



            (Result,Results,p,q,var_num,clause_num,Time) = ImproveDecision(totalround,objLowerBound,objUpperBound,RestrictSUM100_1)
            count_var_num += var_num
            count_clause_num += clause_num
            count_time += Time

            if Result == "UNSATISFIABLE":
                continue

            SUM100_1 = 0
            SUM100_2 = 0
            SUM100_3 = 0

            for i in range(totalround):
                for j in range(16):
                    if  (Results[p[i][j]-1] < 0) and (Results[q[i][j]-1] > 0) :
                        SUM100_1 += 1
                    if   (Results[p[i][j]-1] > 0) and (Results[q[i][j]-1] < 0):
                        SUM100_2 += 1
                    if   (Results[p[i][j]-1] > 0) and (Results[q[i][j]-1] > 0):
                        SUM100_3 += 1
        
        
        if SUM100_1 < 3:
            TheTrueProbability100 = 1.415*SUM100_1 + 2*SUM100_2 + 3*SUM100_3

            Total_var_num += count_var_num
            Total_clause_num += count_clause_num
            Total_Solve_time += count_time

            file = open("RunTimeSummarise.out", "a")
            resultseq = "Round: " + str(totalround) + "; Probability: " + str(TheTrueProbability100) + "; Runtime: " + str(count_time) + " count_var_num: " + str(count_var_num) + " count_clause_num: " + str(count_clause_num) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num: " + str(Total_clause_num) +" Total_Solver_time: " + str(Total_Solve_time)  + "\n"
            file.write(resultseq)
            file.close()
            continue
        else:
            print("This may be not the best trails")
            while 1:
                continue


    print(Total_Solve_time)
    file = open("RunTimeSummarise.out", "a")
    resultseq = "Total Time of Solving SAT Model: " + str(Total_Solve_time) + " Total_var_num: " + str(Total_var_num) + " Total_clause_num" + str(Total_clause_num)
    file.write(resultseq)
    file.close()

